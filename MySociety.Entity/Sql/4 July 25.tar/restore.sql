--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "MySociety";
--
-- Name: MySociety; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "MySociety" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE "MySociety" OWNER TO postgres;

\connect "MySociety"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Test; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Test" AS (
	test_name character varying(100),
	test_number integer
);


ALTER TYPE public."Test" OWNER TO postgres;

--
-- Name: get_visitors(integer, text, text, date, date, text, integer, integer, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_visitors(_house_mapping_id integer DEFAULT '-1'::integer, _search text DEFAULT ''::text, _date_range text DEFAULT 'all'::text, _from_date date DEFAULT NULL::date, _to_date date DEFAULT NULL::date, _checkout_status text DEFAULT 'all'::text, _visit_purpose_id integer DEFAULT '-1'::integer, _visitor_status integer DEFAULT '-1'::integer, _sort_column text DEFAULT 'id'::text, _sort_order text DEFAULT 'asc'::text) RETURNS TABLE(house_name character varying, house_mapping_id integer, id integer, name character varying, phone character varying, visit_purpose character varying, no_of_visitors integer, created_at timestamp without time zone, vehicle_no character varying, approval_status character varying, check_in_time timestamp without time zone, check_out_time timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE
    _from_final DATE;
    _to_final DATE;
    _sql TEXT;
BEGIN
    -- Date Range Logic
    _date_range = lower(_date_range);

    IF _date_range = 'today' THEN
        _from_final := CURRENT_DATE;
        _to_final := CURRENT_DATE;
    ELSIF _date_range = 'last7days' THEN
        _from_final := CURRENT_DATE - INTERVAL '7 days';
        _to_final := CURRENT_DATE;
    ELSIF _date_range = 'last30days' THEN
        _from_final := CURRENT_DATE - INTERVAL '30 days';
        _to_final := CURRENT_DATE;
    ELSIF _date_range = 'currentmonth' THEN
        _from_final := date_trunc('month', CURRENT_DATE);
        _to_final := (date_trunc('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::DATE;
    ELSIF _date_range = 'customdate' THEN
        _from_final := _from_date;
        _to_final := _to_date;
    END IF;

    -- Dynamic SQL Assembly
    _sql := 'SELECT
                hm.house_name,
                v.house_mapping_id as house_id,
                v.id, 
                v.name, 
                v.phone, 
                CASE 
                    WHEN vp.name = ''Other'' 
                        THEN v.visit_purpose_reason 
                    ELSE vp.name 
                    END 
                AS visit_purpose, 
                v.no_of_visitors, 
                v.created_at, 
                v.vehicle_no, 
                vs.name AS approval_status, 
                v.check_in_time, 
                v.check_out_time
            FROM "Visitors" v
            JOIN "VisitPurpose" vp ON v.visit_purpose_id = vp.id
            JOIN "VisitorStatus" vs ON v.status_id = vs.id
            JOIN "HouseMapping" hm on v.house_mapping_id = hm.id
            WHERE v.deleted_by IS NULL';

    -- User-based filter
    IF _house_mapping_id != -1 THEN
        _sql := _sql || ' AND v.house_mapping_id = ' || _house_mapping_id;
    END IF;

    -- Search filter
    IF trim(_search) <> '' THEN
        _sql := _sql || ' AND lower(replace(v.name, '' '', '''')) LIKE ''%' || replace(lower(_search), '''', '''''') || '%''';
    END IF;

    -- Date filter
    IF _date_range <> 'all' AND _from_final IS NOT NULL AND _to_final IS NOT NULL THEN
        _sql := _sql || ' AND v.created_at::DATE BETWEEN ''' || _from_final || ''' AND ''' || _to_final || '''';
    END IF;

    -- Visit Purpose filter
    IF _visit_purpose_id != -1 THEN
        _sql := _sql || ' AND v.visit_purpose_id = ' || _visit_purpose_id;
    END IF;

    -- Visitor Status filter
    IF _visitor_status != -1 THEN
        _sql := _sql || ' AND v.status_id = ' || _visitor_status;
    END IF;

    -- Check Out Status filter
    _checkout_status = lower(_checkout_status);

    IF _checkout_status = 'current' THEN
        _sql := _sql || ' AND v.check_in_time IS NOT NULL AND v.check_out_time IS NULL';
    ELSIF _checkout_status = 'checked out' THEN
        _sql := _sql || ' AND v.check_in_time IS NOT NULL AND v.check_out_time IS NOT NULL';
    END IF;

    -- Sorting
    CASE lower(_sort_column)
        WHEN 'house' THEN _sort_column := 'v.house_mapping_id';
        WHEN 'name' THEN _sort_column := 'v.name';
        WHEN 'phone' THEN _sort_column := 'v.phone';
        WHEN 'purpose' THEN _sort_column := 'vp.name';
        WHEN 'noofvisitors' THEN _sort_column := 'v.no_of_visitors';
        WHEN 'vehicle' THEN _sort_column := 'v.vehicle_no';
        WHEN 'checkin' THEN _sort_column := 'v.check_in_time';
        WHEN 'checkout' THEN _sort_column := 'v.check_out_time';
        ELSE _sort_column := 'v.id';
    END CASE;

    IF lower(_sort_order) NOT IN ('asc', 'desc') THEN
        _sort_order := 'asc';
    END IF;

    -- Final ORDER BY
    _sql := _sql || ' ORDER BY ' || _sort_column || ' ' || _sort_order;

    -- Execute dynamic SQL safely
    RETURN QUERY EXECUTE _sql;

END;
$$;


ALTER FUNCTION public.get_visitors(_house_mapping_id integer, _search text, _date_range text, _from_date date, _to_date date, _checkout_status text, _visit_purpose_id integer, _visitor_status integer, _sort_column text, _sort_order text) OWNER TO postgres;

--
-- Name: test_prodecure(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.test_prodecure(OUT test refcursor)
    LANGUAGE plpgsql
    AS $$
BEGIN
    SELECT name, id FROM "Users";
END;
$$;


ALTER PROCEDURE public.test_prodecure(OUT test refcursor) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AudienceGroupMembers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AudienceGroupMembers" (
    id integer NOT NULL,
    audience_group_id integer NOT NULL,
    member_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer
);


ALTER TABLE public."AudienceGroupMembers" OWNER TO postgres;

--
-- Name: AudienceGroupMembers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AudienceGroupMembers_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AudienceGroupMembers_id_seq" OWNER TO postgres;

--
-- Name: AudienceGroupMembers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AudienceGroupMembers_id_seq" OWNED BY public."AudienceGroupMembers".id;


--
-- Name: AudienceGroupTypes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AudienceGroupTypes" (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public."AudienceGroupTypes" OWNER TO postgres;

--
-- Name: AudienceGroupTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AudienceGroupTypes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AudienceGroupTypes_id_seq" OWNER TO postgres;

--
-- Name: AudienceGroupTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AudienceGroupTypes_id_seq" OWNED BY public."AudienceGroupTypes".id;


--
-- Name: AudienceGroups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AudienceGroups" (
    id integer NOT NULL,
    group_name character varying(100) NOT NULL,
    description character varying(500) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer
);


ALTER TABLE public."AudienceGroups" OWNER TO postgres;

--
-- Name: AudienceGroups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AudienceGroups_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AudienceGroups_id_seq" OWNER TO postgres;

--
-- Name: AudienceGroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AudienceGroups_id_seq" OWNED BY public."AudienceGroups".id;


--
-- Name: Blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Blocks" (
    id integer NOT NULL,
    block_number integer NOT NULL,
    name character varying(100) NOT NULL,
    no_of_floor integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer
);


ALTER TABLE public."Blocks" OWNER TO postgres;

--
-- Name: Blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Blocks_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Blocks_id_seq" OWNER TO postgres;

--
-- Name: Blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Blocks_id_seq" OWNED BY public."Blocks".id;


--
-- Name: Floors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Floors" (
    id integer NOT NULL,
    floor_number integer NOT NULL,
    name character varying(100) NOT NULL,
    no_of_house integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer
);


ALTER TABLE public."Floors" OWNER TO postgres;

--
-- Name: Floors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Floors_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Floors_id_seq" OWNER TO postgres;

--
-- Name: Floors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Floors_id_seq" OWNED BY public."Floors".id;


--
-- Name: HouseMapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."HouseMapping" (
    id integer NOT NULL,
    block_id integer NOT NULL,
    floor_id integer NOT NULL,
    house_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer,
    house_name character varying(15)
);


ALTER TABLE public."HouseMapping" OWNER TO postgres;

--
-- Name: HouseMapping_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."HouseMapping_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."HouseMapping_id_seq" OWNER TO postgres;

--
-- Name: HouseMapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."HouseMapping_id_seq" OWNED BY public."HouseMapping".id;


--
-- Name: Houses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Houses" (
    id integer NOT NULL,
    house_number integer NOT NULL,
    name character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer
);


ALTER TABLE public."Houses" OWNER TO postgres;

--
-- Name: Houses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Houses_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Houses_id_seq" OWNER TO postgres;

--
-- Name: Houses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Houses_id_seq" OWNED BY public."Houses".id;


--
-- Name: NoticeAttachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NoticeAttachments" (
    id integer NOT NULL,
    notice_id integer NOT NULL,
    name character varying NOT NULL,
    path integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer
);


ALTER TABLE public."NoticeAttachments" OWNER TO postgres;

--
-- Name: NoticeAttachments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."NoticeAttachments_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."NoticeAttachments_id_seq" OWNER TO postgres;

--
-- Name: NoticeAttachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."NoticeAttachments_id_seq" OWNED BY public."NoticeAttachments".id;


--
-- Name: NoticeAudienceMapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NoticeAudienceMapping" (
    id integer NOT NULL,
    notice_id integer,
    group_type_id integer NOT NULL,
    reference_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer
);


ALTER TABLE public."NoticeAudienceMapping" OWNER TO postgres;

--
-- Name: NoticeAudienceMapping_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."NoticeAudienceMapping_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."NoticeAudienceMapping_id_seq" OWNER TO postgres;

--
-- Name: NoticeAudienceMapping_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."NoticeAudienceMapping_id_seq" OWNED BY public."NoticeAudienceMapping".id;


--
-- Name: NoticeCategories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NoticeCategories" (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public."NoticeCategories" OWNER TO postgres;

--
-- Name: NoticeCategories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."NoticeCategories_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."NoticeCategories_id_seq" OWNER TO postgres;

--
-- Name: NoticeCategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."NoticeCategories_id_seq" OWNED BY public."NoticeCategories".id;


--
-- Name: Notices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notices" (
    id integer NOT NULL,
    title character varying(100) NOT NULL,
    description character varying NOT NULL,
    notice_category_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer
);


ALTER TABLE public."Notices" OWNER TO postgres;

--
-- Name: Notices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Notices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Notices_id_seq" OWNER TO postgres;

--
-- Name: Notices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Notices_id_seq" OWNED BY public."Notices".id;


--
-- Name: NotificationCategories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NotificationCategories" (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public."NotificationCategories" OWNER TO postgres;

--
-- Name: NotificationCategories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."NotificationCategories_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."NotificationCategories_id_seq" OWNER TO postgres;

--
-- Name: NotificationCategories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."NotificationCategories_id_seq" OWNED BY public."NotificationCategories".id;


--
-- Name: Notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notifications" (
    id integer NOT NULL,
    sender_id integer,
    receiver_id integer NOT NULL,
    message character varying(500) NOT NULL,
    read_at timestamp without time zone,
    target_entity character varying(100),
    target_id integer,
    target_url character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    target_entity_id integer
);


ALTER TABLE public."Notifications" OWNER TO postgres;

--
-- Name: Notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Notifications_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Notifications_id_seq" OWNER TO postgres;

--
-- Name: Notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Notifications_id_seq" OWNED BY public."Notifications".id;


--
-- Name: ResetPasswordToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ResetPasswordToken" (
    id integer NOT NULL,
    email character varying NOT NULL,
    token character varying NOT NULL,
    is_used boolean DEFAULT false NOT NULL,
    expirytime timestamp without time zone DEFAULT (CURRENT_TIMESTAMP + '24:00:00'::interval) NOT NULL
);


ALTER TABLE public."ResetPasswordToken" OWNER TO postgres;

--
-- Name: ResetPasswordToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ResetPasswordToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ResetPasswordToken_id_seq" OWNER TO postgres;

--
-- Name: ResetPasswordToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ResetPasswordToken_id_seq" OWNED BY public."ResetPasswordToken".id;


--
-- Name: Roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Roles" (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(500)
);


ALTER TABLE public."Roles" OWNER TO postgres;

--
-- Name: Roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Roles_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Roles_id_seq" OWNER TO postgres;

--
-- Name: Roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Roles_id_seq" OWNED BY public."Roles".id;


--
-- Name: UserOtp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."UserOtp" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    otp_code character varying(8) NOT NULL,
    expiry_time timestamp without time zone DEFAULT (CURRENT_TIMESTAMP + '00:10:00'::interval) NOT NULL,
    is_used boolean DEFAULT false NOT NULL
);


ALTER TABLE public."UserOtp" OWNER TO postgres;

--
-- Name: UserOtp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."UserOtp_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserOtp_id_seq" OWNER TO postgres;

--
-- Name: UserOtp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."UserOtp_id_seq" OWNED BY public."UserOtp".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    role_id integer NOT NULL,
    email character varying NOT NULL,
    password character varying(255) NOT NULL,
    name character varying(50) NOT NULL,
    profile_img character varying,
    phone character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer,
    is_approved boolean,
    house_unit_id integer
);


ALTER TABLE public."Users" OWNER TO postgres;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Users_id_seq" OWNER TO postgres;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: VehicleType; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VehicleType" (
    id integer NOT NULL,
    name character varying(50)
);


ALTER TABLE public."VehicleType" OWNER TO postgres;

--
-- Name: VehicleType_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."VehicleType_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."VehicleType_id_seq" OWNER TO postgres;

--
-- Name: VehicleType_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."VehicleType_id_seq" OWNED BY public."VehicleType".id;


--
-- Name: Vehicles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Vehicles" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    vehicle_number character varying(15) NOT NULL,
    name character varying(255) NOT NULL,
    vehicle_type_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer,
    parking_slot_no integer
);


ALTER TABLE public."Vehicles" OWNER TO postgres;

--
-- Name: Vehicles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Vehicles_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Vehicles_id_seq" OWNER TO postgres;

--
-- Name: Vehicles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Vehicles_id_seq" OWNED BY public."Vehicles".id;


--
-- Name: VisitPurpose; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VisitPurpose" (
    id integer NOT NULL,
    name character varying(255)
);


ALTER TABLE public."VisitPurpose" OWNER TO postgres;

--
-- Name: VisitPurpose_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."VisitPurpose_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."VisitPurpose_id_seq" OWNER TO postgres;

--
-- Name: VisitPurpose_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."VisitPurpose_id_seq" OWNED BY public."VisitPurpose".id;


--
-- Name: VisitorFeedbacks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VisitorFeedbacks" (
    id integer NOT NULL,
    visitor_id integer NOT NULL,
    rating integer,
    feedback character varying(500),
    CONSTRAINT "VisitorFeedbacks_rating_check" CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public."VisitorFeedbacks" OWNER TO postgres;

--
-- Name: VisitorFeedbacks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."VisitorFeedbacks_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."VisitorFeedbacks_id_seq" OWNER TO postgres;

--
-- Name: VisitorFeedbacks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."VisitorFeedbacks_id_seq" OWNED BY public."VisitorFeedbacks".id;


--
-- Name: VisitorStatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VisitorStatus" (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public."VisitorStatus" OWNER TO postgres;

--
-- Name: VisitorStatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."VisitorStatus_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."VisitorStatus_id_seq" OWNER TO postgres;

--
-- Name: VisitorStatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."VisitorStatus_id_seq" OWNED BY public."VisitorStatus".id;


--
-- Name: Visitors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Visitors" (
    id integer NOT NULL,
    house_mapping_id integer NOT NULL,
    name character varying(100) NOT NULL,
    phone character varying NOT NULL,
    visit_purpose_id integer NOT NULL,
    no_of_visitors integer NOT NULL,
    check_in_time timestamp without time zone,
    check_out_time timestamp without time zone,
    vehicle_no character varying(15),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by integer NOT NULL,
    deleted_at timestamp without time zone,
    deleted_by integer,
    visit_purpose_reason character varying,
    status_id integer NOT NULL
);


ALTER TABLE public."Visitors" OWNER TO postgres;

--
-- Name: Visitors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Visitors_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Visitors_id_seq" OWNER TO postgres;

--
-- Name: Visitors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Visitors_id_seq" OWNED BY public."Visitors".id;


--
-- Name: AudienceGroupMembers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroupMembers" ALTER COLUMN id SET DEFAULT nextval('public."AudienceGroupMembers_id_seq"'::regclass);


--
-- Name: AudienceGroupTypes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroupTypes" ALTER COLUMN id SET DEFAULT nextval('public."AudienceGroupTypes_id_seq"'::regclass);


--
-- Name: AudienceGroups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroups" ALTER COLUMN id SET DEFAULT nextval('public."AudienceGroups_id_seq"'::regclass);


--
-- Name: Blocks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Blocks" ALTER COLUMN id SET DEFAULT nextval('public."Blocks_id_seq"'::regclass);


--
-- Name: Floors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Floors" ALTER COLUMN id SET DEFAULT nextval('public."Floors_id_seq"'::regclass);


--
-- Name: HouseMapping id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."HouseMapping" ALTER COLUMN id SET DEFAULT nextval('public."HouseMapping_id_seq"'::regclass);


--
-- Name: Houses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Houses" ALTER COLUMN id SET DEFAULT nextval('public."Houses_id_seq"'::regclass);


--
-- Name: NoticeAttachments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeAttachments" ALTER COLUMN id SET DEFAULT nextval('public."NoticeAttachments_id_seq"'::regclass);


--
-- Name: NoticeAudienceMapping id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeAudienceMapping" ALTER COLUMN id SET DEFAULT nextval('public."NoticeAudienceMapping_id_seq"'::regclass);


--
-- Name: NoticeCategories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeCategories" ALTER COLUMN id SET DEFAULT nextval('public."NoticeCategories_id_seq"'::regclass);


--
-- Name: Notices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notices" ALTER COLUMN id SET DEFAULT nextval('public."Notices_id_seq"'::regclass);


--
-- Name: NotificationCategories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationCategories" ALTER COLUMN id SET DEFAULT nextval('public."NotificationCategories_id_seq"'::regclass);


--
-- Name: Notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notifications" ALTER COLUMN id SET DEFAULT nextval('public."Notifications_id_seq"'::regclass);


--
-- Name: ResetPasswordToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResetPasswordToken" ALTER COLUMN id SET DEFAULT nextval('public."ResetPasswordToken_id_seq"'::regclass);


--
-- Name: Roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles" ALTER COLUMN id SET DEFAULT nextval('public."Roles_id_seq"'::regclass);


--
-- Name: UserOtp id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserOtp" ALTER COLUMN id SET DEFAULT nextval('public."UserOtp_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Name: VehicleType id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VehicleType" ALTER COLUMN id SET DEFAULT nextval('public."VehicleType_id_seq"'::regclass);


--
-- Name: Vehicles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles" ALTER COLUMN id SET DEFAULT nextval('public."Vehicles_id_seq"'::regclass);


--
-- Name: VisitPurpose id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VisitPurpose" ALTER COLUMN id SET DEFAULT nextval('public."VisitPurpose_id_seq"'::regclass);


--
-- Name: VisitorFeedbacks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VisitorFeedbacks" ALTER COLUMN id SET DEFAULT nextval('public."VisitorFeedbacks_id_seq"'::regclass);


--
-- Name: VisitorStatus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VisitorStatus" ALTER COLUMN id SET DEFAULT nextval('public."VisitorStatus_id_seq"'::regclass);


--
-- Name: Visitors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visitors" ALTER COLUMN id SET DEFAULT nextval('public."Visitors_id_seq"'::regclass);


--
-- Data for Name: AudienceGroupMembers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AudienceGroupMembers" (id, audience_group_id, member_id, created_at, created_by, deleted_at, deleted_by) FROM stdin;
\.
COPY public."AudienceGroupMembers" (id, audience_group_id, member_id, created_at, created_by, deleted_at, deleted_by) FROM '$$PATH$$/5124.dat';

--
-- Data for Name: AudienceGroupTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AudienceGroupTypes" (id, name) FROM stdin;
\.
COPY public."AudienceGroupTypes" (id, name) FROM '$$PATH$$/5120.dat';

--
-- Data for Name: AudienceGroups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AudienceGroups" (id, group_name, description, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by) FROM stdin;
\.
COPY public."AudienceGroups" (id, group_name, description, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by) FROM '$$PATH$$/5122.dat';

--
-- Data for Name: Blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Blocks" (id, block_number, name, no_of_floor, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by) FROM stdin;
\.
COPY public."Blocks" (id, block_number, name, no_of_floor, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by) FROM '$$PATH$$/5081.dat';

--
-- Data for Name: Floors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Floors" (id, floor_number, name, no_of_house, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by) FROM stdin;
\.
COPY public."Floors" (id, floor_number, name, no_of_house, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by) FROM '$$PATH$$/5083.dat';

--
-- Data for Name: HouseMapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."HouseMapping" (id, block_id, floor_id, house_id, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, house_name) FROM stdin;
\.
COPY public."HouseMapping" (id, block_id, floor_id, house_id, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, house_name) FROM '$$PATH$$/5085.dat';

--
-- Data for Name: Houses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Houses" (id, house_number, name, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by) FROM stdin;
\.
COPY public."Houses" (id, house_number, name, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by) FROM '$$PATH$$/5087.dat';

--
-- Data for Name: NoticeAttachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NoticeAttachments" (id, notice_id, name, path, created_at, created_by, deleted_at, deleted_by) FROM stdin;
\.
COPY public."NoticeAttachments" (id, notice_id, name, path, created_at, created_by, deleted_at, deleted_by) FROM '$$PATH$$/5118.dat';

--
-- Data for Name: NoticeAudienceMapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NoticeAudienceMapping" (id, notice_id, group_type_id, reference_id, created_at, created_by, deleted_at, deleted_by) FROM stdin;
\.
COPY public."NoticeAudienceMapping" (id, notice_id, group_type_id, reference_id, created_at, created_by, deleted_at, deleted_by) FROM '$$PATH$$/5126.dat';

--
-- Data for Name: NoticeCategories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NoticeCategories" (id, name) FROM stdin;
\.
COPY public."NoticeCategories" (id, name) FROM '$$PATH$$/5114.dat';

--
-- Data for Name: Notices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notices" (id, title, description, notice_category_id, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by) FROM stdin;
\.
COPY public."Notices" (id, title, description, notice_category_id, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by) FROM '$$PATH$$/5116.dat';

--
-- Data for Name: NotificationCategories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NotificationCategories" (id, name) FROM stdin;
\.
COPY public."NotificationCategories" (id, name) FROM '$$PATH$$/5110.dat';

--
-- Data for Name: Notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notifications" (id, sender_id, receiver_id, message, read_at, target_entity, target_id, target_url, created_at, target_entity_id) FROM stdin;
\.
COPY public."Notifications" (id, sender_id, receiver_id, message, read_at, target_entity, target_id, target_url, created_at, target_entity_id) FROM '$$PATH$$/5108.dat';

--
-- Data for Name: ResetPasswordToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ResetPasswordToken" (id, email, token, is_used, expirytime) FROM stdin;
\.
COPY public."ResetPasswordToken" (id, email, token, is_used, expirytime) FROM '$$PATH$$/5089.dat';

--
-- Data for Name: Roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Roles" (id, name, description) FROM stdin;
\.
COPY public."Roles" (id, name, description) FROM '$$PATH$$/5091.dat';

--
-- Data for Name: UserOtp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."UserOtp" (id, user_id, otp_code, expiry_time, is_used) FROM stdin;
\.
COPY public."UserOtp" (id, user_id, otp_code, expiry_time, is_used) FROM '$$PATH$$/5093.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" (id, role_id, email, password, name, profile_img, phone, is_active, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, is_approved, house_unit_id) FROM stdin;
\.
COPY public."Users" (id, role_id, email, password, name, profile_img, phone, is_active, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, is_approved, house_unit_id) FROM '$$PATH$$/5095.dat';

--
-- Data for Name: VehicleType; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VehicleType" (id, name) FROM stdin;
\.
COPY public."VehicleType" (id, name) FROM '$$PATH$$/5097.dat';

--
-- Data for Name: Vehicles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Vehicles" (id, user_id, vehicle_number, name, vehicle_type_id, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, parking_slot_no) FROM stdin;
\.
COPY public."Vehicles" (id, user_id, vehicle_number, name, vehicle_type_id, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, parking_slot_no) FROM '$$PATH$$/5099.dat';

--
-- Data for Name: VisitPurpose; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VisitPurpose" (id, name) FROM stdin;
\.
COPY public."VisitPurpose" (id, name) FROM '$$PATH$$/5101.dat';

--
-- Data for Name: VisitorFeedbacks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VisitorFeedbacks" (id, visitor_id, rating, feedback) FROM stdin;
\.
COPY public."VisitorFeedbacks" (id, visitor_id, rating, feedback) FROM '$$PATH$$/5106.dat';

--
-- Data for Name: VisitorStatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VisitorStatus" (id, name) FROM stdin;
\.
COPY public."VisitorStatus" (id, name) FROM '$$PATH$$/5112.dat';

--
-- Data for Name: Visitors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Visitors" (id, house_mapping_id, name, phone, visit_purpose_id, no_of_visitors, check_in_time, check_out_time, vehicle_no, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, visit_purpose_reason, status_id) FROM stdin;
\.
COPY public."Visitors" (id, house_mapping_id, name, phone, visit_purpose_id, no_of_visitors, check_in_time, check_out_time, vehicle_no, created_at, created_by, updated_at, updated_by, deleted_at, deleted_by, visit_purpose_reason, status_id) FROM '$$PATH$$/5103.dat';

--
-- Name: AudienceGroupMembers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AudienceGroupMembers_id_seq"', 1, false);


--
-- Name: AudienceGroupTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AudienceGroupTypes_id_seq"', 6, true);


--
-- Name: AudienceGroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AudienceGroups_id_seq"', 1, false);


--
-- Name: Blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Blocks_id_seq"', 4, true);


--
-- Name: Floors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Floors_id_seq"', 5, true);


--
-- Name: HouseMapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."HouseMapping_id_seq"', 64, true);


--
-- Name: Houses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Houses_id_seq"', 4, true);


--
-- Name: NoticeAttachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."NoticeAttachments_id_seq"', 1, false);


--
-- Name: NoticeAudienceMapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."NoticeAudienceMapping_id_seq"', 1, false);


--
-- Name: NoticeCategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."NoticeCategories_id_seq"', 9, true);


--
-- Name: Notices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Notices_id_seq"', 2, true);


--
-- Name: NotificationCategories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."NotificationCategories_id_seq"', 3, true);


--
-- Name: Notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Notifications_id_seq"', 63, true);


--
-- Name: ResetPasswordToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ResetPasswordToken_id_seq"', 8, true);


--
-- Name: Roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Roles_id_seq"', 6, true);


--
-- Name: UserOtp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."UserOtp_id_seq"', 67, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Users_id_seq"', 31, true);


--
-- Name: VehicleType_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VehicleType_id_seq"', 4, true);


--
-- Name: Vehicles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Vehicles_id_seq"', 6, true);


--
-- Name: VisitPurpose_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VisitPurpose_id_seq"', 4, true);


--
-- Name: VisitorFeedbacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VisitorFeedbacks_id_seq"', 8, true);


--
-- Name: VisitorStatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VisitorStatus_id_seq"', 4, true);


--
-- Name: Visitors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Visitors_id_seq"', 50, true);


--
-- Name: AudienceGroupMembers AudienceGroupMembers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroupMembers"
    ADD CONSTRAINT "AudienceGroupMembers_pkey" PRIMARY KEY (id);


--
-- Name: AudienceGroupTypes AudienceGroupTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroupTypes"
    ADD CONSTRAINT "AudienceGroupTypes_pkey" PRIMARY KEY (id);


--
-- Name: AudienceGroups AudienceGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroups"
    ADD CONSTRAINT "AudienceGroups_pkey" PRIMARY KEY (id);


--
-- Name: Blocks Blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Blocks"
    ADD CONSTRAINT "Blocks_pkey" PRIMARY KEY (id);


--
-- Name: Floors Floors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Floors"
    ADD CONSTRAINT "Floors_pkey" PRIMARY KEY (id);


--
-- Name: HouseMapping HouseMapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."HouseMapping"
    ADD CONSTRAINT "HouseMapping_pkey" PRIMARY KEY (id);


--
-- Name: Houses Houses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Houses"
    ADD CONSTRAINT "Houses_pkey" PRIMARY KEY (id);


--
-- Name: NoticeAttachments NoticeAttachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeAttachments"
    ADD CONSTRAINT "NoticeAttachments_pkey" PRIMARY KEY (id);


--
-- Name: NoticeAudienceMapping NoticeAudienceMapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeAudienceMapping"
    ADD CONSTRAINT "NoticeAudienceMapping_pkey" PRIMARY KEY (id);


--
-- Name: NoticeCategories NoticeCategories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeCategories"
    ADD CONSTRAINT "NoticeCategories_pkey" PRIMARY KEY (id);


--
-- Name: Notices Notices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notices"
    ADD CONSTRAINT "Notices_pkey" PRIMARY KEY (id);


--
-- Name: NotificationCategories NotificationCategories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationCategories"
    ADD CONSTRAINT "NotificationCategories_pkey" PRIMARY KEY (id);


--
-- Name: Notifications Notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "Notifications_pkey" PRIMARY KEY (id);


--
-- Name: ResetPasswordToken ResetPasswordToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResetPasswordToken"
    ADD CONSTRAINT "ResetPasswordToken_pkey" PRIMARY KEY (id);


--
-- Name: Roles Roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_pkey" PRIMARY KEY (id);


--
-- Name: UserOtp UserOtp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserOtp"
    ADD CONSTRAINT "UserOtp_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: VehicleType VehicleType_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VehicleType"
    ADD CONSTRAINT "VehicleType_pkey" PRIMARY KEY (id);


--
-- Name: Vehicles Vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_pkey" PRIMARY KEY (id);


--
-- Name: VisitPurpose VisitPurpose_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VisitPurpose"
    ADD CONSTRAINT "VisitPurpose_pkey" PRIMARY KEY (id);


--
-- Name: VisitorFeedbacks VisitorFeedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VisitorFeedbacks"
    ADD CONSTRAINT "VisitorFeedbacks_pkey" PRIMARY KEY (id);


--
-- Name: VisitorStatus VisitorStatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VisitorStatus"
    ADD CONSTRAINT "VisitorStatus_pkey" PRIMARY KEY (id);


--
-- Name: Visitors Visitors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visitors"
    ADD CONSTRAINT "Visitors_pkey" PRIMARY KEY (id);


--
-- Name: AudienceGroupMembers AudienceGroupMembers_audience_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroupMembers"
    ADD CONSTRAINT "AudienceGroupMembers_audience_group_id_fkey" FOREIGN KEY (audience_group_id) REFERENCES public."AudienceGroups"(id) ON DELETE CASCADE;


--
-- Name: AudienceGroupMembers AudienceGroupMembers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroupMembers"
    ADD CONSTRAINT "AudienceGroupMembers_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public."Users"(id);


--
-- Name: AudienceGroupMembers AudienceGroupMembers_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroupMembers"
    ADD CONSTRAINT "AudienceGroupMembers_member_id_fkey" FOREIGN KEY (member_id) REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- Name: AudienceGroups AudienceGroups_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroups"
    ADD CONSTRAINT "AudienceGroups_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public."Users"(id);


--
-- Name: AudienceGroups AudienceGroups_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AudienceGroups"
    ADD CONSTRAINT "AudienceGroups_updated_by_fkey" FOREIGN KEY (updated_by) REFERENCES public."Users"(id);


--
-- Name: Blocks Blocks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Blocks"
    ADD CONSTRAINT "Blocks_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public."Users"(id);


--
-- Name: Blocks Blocks_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Blocks"
    ADD CONSTRAINT "Blocks_updated_by_fkey" FOREIGN KEY (updated_by) REFERENCES public."Users"(id);


--
-- Name: Floors Floors_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Floors"
    ADD CONSTRAINT "Floors_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public."Users"(id);


--
-- Name: Floors Floors_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Floors"
    ADD CONSTRAINT "Floors_updated_by_fkey" FOREIGN KEY (updated_by) REFERENCES public."Users"(id);


--
-- Name: HouseMapping HouseMapping_block_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."HouseMapping"
    ADD CONSTRAINT "HouseMapping_block_id_fkey" FOREIGN KEY (block_id) REFERENCES public."Blocks"(id);


--
-- Name: HouseMapping HouseMapping_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."HouseMapping"
    ADD CONSTRAINT "HouseMapping_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public."Users"(id);


--
-- Name: HouseMapping HouseMapping_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."HouseMapping"
    ADD CONSTRAINT "HouseMapping_floor_id_fkey" FOREIGN KEY (floor_id) REFERENCES public."Floors"(id);


--
-- Name: HouseMapping HouseMapping_house_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."HouseMapping"
    ADD CONSTRAINT "HouseMapping_house_id_fkey" FOREIGN KEY (house_id) REFERENCES public."Houses"(id);


--
-- Name: HouseMapping HouseMapping_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."HouseMapping"
    ADD CONSTRAINT "HouseMapping_updated_by_fkey" FOREIGN KEY (updated_by) REFERENCES public."Users"(id);


--
-- Name: Houses Houses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Houses"
    ADD CONSTRAINT "Houses_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public."Users"(id);


--
-- Name: Houses Houses_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Houses"
    ADD CONSTRAINT "Houses_updated_by_fkey" FOREIGN KEY (updated_by) REFERENCES public."Users"(id);


--
-- Name: NoticeAttachments NoticeAttachments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeAttachments"
    ADD CONSTRAINT "NoticeAttachments_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public."Users"(id);


--
-- Name: NoticeAttachments NoticeAttachments_notice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeAttachments"
    ADD CONSTRAINT "NoticeAttachments_notice_id_fkey" FOREIGN KEY (notice_id) REFERENCES public."Notices"(id);


--
-- Name: NoticeAudienceMapping NoticeAudienceMapping_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeAudienceMapping"
    ADD CONSTRAINT "NoticeAudienceMapping_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public."Users"(id);


--
-- Name: NoticeAudienceMapping NoticeAudienceMapping_group_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeAudienceMapping"
    ADD CONSTRAINT "NoticeAudienceMapping_group_type_id_fkey" FOREIGN KEY (group_type_id) REFERENCES public."AudienceGroupTypes"(id);


--
-- Name: NoticeAudienceMapping NoticeAudienceMapping_notice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NoticeAudienceMapping"
    ADD CONSTRAINT "NoticeAudienceMapping_notice_id_fkey" FOREIGN KEY (notice_id) REFERENCES public."Notices"(id) ON DELETE CASCADE;


--
-- Name: Notices Notices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notices"
    ADD CONSTRAINT "Notices_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public."Users"(id);


--
-- Name: Notices Notices_notice_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notices"
    ADD CONSTRAINT "Notices_notice_category_id_fkey" FOREIGN KEY (notice_category_id) REFERENCES public."NoticeCategories"(id);


--
-- Name: Notices Notices_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notices"
    ADD CONSTRAINT "Notices_updated_by_fkey" FOREIGN KEY (updated_by) REFERENCES public."Users"(id);


--
-- Name: Notifications Notifications_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "Notifications_receiver_id_fkey" FOREIGN KEY (receiver_id) REFERENCES public."Users"(id);


--
-- Name: Notifications Notifications_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "Notifications_sender_id_fkey" FOREIGN KEY (sender_id) REFERENCES public."Users"(id);


--
-- Name: UserOtp UserOtp_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."UserOtp"
    ADD CONSTRAINT "UserOtp_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."Users"(id);


--
-- Name: Users Users_house_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_house_unit_id_fkey" FOREIGN KEY (house_unit_id) REFERENCES public."HouseMapping"(id);


--
-- Name: Users Users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_role_id_fkey" FOREIGN KEY (role_id) REFERENCES public."Roles"(id);


--
-- Name: Vehicles Vehicles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_created_by_fkey" FOREIGN KEY (created_by) REFERENCES public."Users"(id);


--
-- Name: Vehicles Vehicles_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_updated_by_fkey" FOREIGN KEY (updated_by) REFERENCES public."Users"(id);


--
-- Name: Vehicles Vehicles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."Users"(id);


--
-- Name: Vehicles Vehicles_vehicle_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vehicles"
    ADD CONSTRAINT "Vehicles_vehicle_type_id_fkey" FOREIGN KEY (vehicle_type_id) REFERENCES public."VehicleType"(id);


--
-- Name: VisitorFeedbacks VisitorFeedbacks_visitor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VisitorFeedbacks"
    ADD CONSTRAINT "VisitorFeedbacks_visitor_id_fkey" FOREIGN KEY (visitor_id) REFERENCES public."Visitors"(id);


--
-- Name: Visitors Visitors_house_mapping_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visitors"
    ADD CONSTRAINT "Visitors_house_mapping_id_fkey" FOREIGN KEY (house_mapping_id) REFERENCES public."HouseMapping"(id);


--
-- Name: Visitors Visitors_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visitors"
    ADD CONSTRAINT "Visitors_status_id_fkey" FOREIGN KEY (status_id) REFERENCES public."VisitorStatus"(id);


--
-- Name: Visitors Visitors_visit_purpose_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Visitors"
    ADD CONSTRAINT "Visitors_visit_purpose_id_fkey" FOREIGN KEY (visit_purpose_id) REFERENCES public."VisitPurpose"(id);


--
-- PostgreSQL database dump complete
--

